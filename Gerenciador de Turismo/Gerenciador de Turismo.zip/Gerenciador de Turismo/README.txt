Seja bem-vindo ao Gerenciador de Turismo, versão 1.0. Este programa foi desenvolvido como parte do trabalho de extensão da disciplina de Programação Orientada a objetos em Java. Para usá-lo, basta clicar no arquivo executável na pasta.

Atenção: Não apague a pasta resources, uma vez que o banco de dados do programa está localizado nesta pasta.